/* PROJECT:  GnpAndLifeExp
 * AUTHOR:  
 * DESCRIPTION:  This uses life expectancy and GNP per capita data from an
 *      input file to produce an output report file, so the user can examine
 *      whether there is a relationship between those 2 variables.
 * DEFINITIONS:
 *      life expectancy is the "average life expectancy at birth for males &
 *              females combined"
 *      gnp per capita is the "gross national product of a country, divided by 
 *              the country's population" (where the gnp is the total amount 
 *              produced by the country, in equivalent dollars)
 * INPUT FILE:  Countries.csv (which is in the top-level project folder)
 * OUTPUT FILE:  Report.txt file (which must be in the top-level project folder)
 *
 * TO SUBMIT FINISHED PROJECT:
 *      1) do Source/Format to neaten things up before closing project
 *      2) zip up your project
 *      3) email zipped project as an attachment to donna.kaminski@wmich.edu
 *****************************************************************************/
package gnpandlifeexp;

import java.io.*;
import java.util.Scanner;

public class GnpAndLifeExp {

    public static void main(String[] args) throws IOException {
        
        final int MAX_N = 300;
        int n = 0;
        
        //---------------------------------------------------------------------
        // 1) DECLARE PARALLEL ARRAYS FOR  lifeExpectancy (e.g., life) AND
        //                              gnpPerCapita (e.g., gnp)
        // 2) FILL IN THE 2 ARRAYS USING DATA FROM THE Countries.csv FILE).
        // NOTE:  life IS FIELD 2, gnp IS FIELD 4.
        // LOOK AT THE FILE TO SEE WHAT DATA TYPE IS NEEDED FOR EACH.
        //---------------------------------------------------------------------

        // WRITE CODE HERE
        
        
        
        String aLine;
        String[] field = new String[5];
        int i = 0;
        
        // WRITE CODE HERE
        
        
        
        
        
        
        n = i;
        System.out.printf("INFO: n for Countries.csv is %d\n", n);
        //---------------------------------------------------------------------
        // DETERMINE THE 2 "MEDIAN" VALUES AT THE ~ 1/3 AND ~ 2/3 POINTS,
        //      FOR BOTH life AND FOR gnp (SEPARATELY) BY DOING (FOR EACH):
        // 1) SORT A COPY OF ARRAY
        // 2) GET THE VALUES AT index (= n/3-1 SINCE ARRAY STARTS AT 0, NOT 1)
        //      AND AT index * 2, SAY:
        //          gnp1Third, gnp2Third, life1Third, life2Third
        //---------------------------------------------------------------------
       
//        int[] tempGnp = Sort.doSort(gnp,n);
//        double[] tempLife = Sort.doSort(life,n);

          // WRITE CODE HERE
        
        
        //---------------------------------------------------------------------
        // CHECK THAT YOU HAVE THE RIGHT VALUES, WHICH SHOULD BE:
        //      2910 & 9780 (AT LOCATIONS [57] AND [114] IN tempGnp)
        //      67.982707 & 75.031268 (AT SAME LOCATIONS IN tempLife)
        //---------------------------------------------------------------------
//        System.out.printf("INFO: gnpPerCapita: 1/3 median is %d at [%d], " +
//                "2/3 median is %d at [%d]\n",
//                gnp1Third, index, gnp2Third, index * 2);
//        
//        System.out.printf("INFO: LifeExpectancy: 1/3 median is %f at [%d], " +
//                "2/3 median is %f at [%d]\n",
//                life1Third, index, life2Third, index * 2);
        
        //---------------------------------------------------------------------
        // 1) SET UP THE 9 COUNTERS (A 2-D MATRIX OF COUNTERS, 
        //      CORRESPONDING TO LOW, MEDIUM, HIGH gnp's FOR THE ROWS
        //      AND LOW, MEDIUM, HIGH life's FOR THE COLUMNS).
        // 2) DO THE TALLIES BY PROCESSING EACH COUNTRY IN THE PARALLEL ARRAYS.
        //---------------------------------------------------------------------
        int row;
        int col;
        
        // WRITE CODE HERE
        
        
        
        
        
        
        //---------------------------------------------------------------------
        // PRINT FINAL REPORT TO Report.txt FILE.  HERE'S A SAMPLE (WHERE THE
        // NUMBERS AREN'T NECESSARILY CORRECT - I'M JUST SHOWING YOU THE FORMAT):
        /*
REPORT:  Number of countries for each category

        ...LIFE EXPECTANCY...
          LOW  MEDIUM HIGH
GNP     ---------------------
LOW     |  28    20    11
MEDIUM  |  18    17    21
HIGH    |   2    20    38       
        */
        // AFTER USING PRINTLN'S FOR THE HEADING LINES, DO THE DETAIL LINES.
        // SINCE THERE ARE ONLY 3 ROWS OF DETAIL LINES, JUST USE 3 PRINTF'S
        //      WITH THIS FORMAT STRING:
        //          String formatStr = "%-7s | %3d   %3d   %3d\r\n";
        //      AND THE RIGHT label STRING AND 3 CORRECT COUNTERS.
        //---------------------------------------------------------------------

        // WRITE CODE HERE
        
        
        
        
        
        
    } // END OF main METHOD
    //*************************************************************************
    // WRITE 2 PRIVATE METHODS FOR whichRow AND whichCol WHICH DETERMINE THE
    //      row (BASED ON gnp AND ITS 2 MEDIANS)
    // OR   col (BASED ON life AND ITS 2 MEDIANS)
    //------------------------------------------------------------------------
    
    // WRITE CODE HERE



    
    



} // END OF CLASS
