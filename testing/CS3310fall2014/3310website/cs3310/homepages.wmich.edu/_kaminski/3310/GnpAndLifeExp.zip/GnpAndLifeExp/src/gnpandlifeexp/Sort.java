/* CLASS:  Sort               USED BY Correlation PROJECT
 * AUTHOR: 
 * DESCRIPTION:  This sorts of a COPY of the PARAMETER ARRAY & RETURNS it.
 *      (Do NOT SORT the ORIGINAL (parameter) array itself since it is part of
 *          the PARALLEL ARRAYS which will be needed later in the program, with
 *          the 2 arrays still PARALLEL (i.e., paired up for each country).
 * You could use the built-in methods in the Arrays class: e.g., for int array
 *      int[] newArray = Arrays.copyOfRange(parArray, 0, n);    // so 0 to n-1
 *      Arrays.sort(newArray);
 *      return newArray;
 * And you'll need to OVERLOAD the method, with 1 for int's and 1 for double's.
 *****************************************************************************/
package gnpandlifeexp;

import java.util.Arrays;            // <<<<<<<<<<<

public class Sort {
    
    // WRITE CODE HERE
    
    //-------------------------------------------------------------------------

    // WRITE CODE HERE
}
