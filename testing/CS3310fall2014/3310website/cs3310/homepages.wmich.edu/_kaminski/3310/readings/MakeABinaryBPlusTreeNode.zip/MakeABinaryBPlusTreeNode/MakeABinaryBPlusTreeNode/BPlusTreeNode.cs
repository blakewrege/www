﻿using System;

namespace MakeABinaryBPlusTreeNode
{
    class BPlusTreeNode
    {
        //********************* THE INTERNAL BINARY NODE ****************************
        public char leafOrNonLeaf;
        public string[] countryCode = new string[Globals.m];
        public int[] drpOrTp = new int[Globals.m];
        public int nextLeaf;
        //********************* PUBLIC METHODS **************************************

        //-------------------------------------------------------------------------
        // This transforms an external ASCII TEXT node from the file (a text file,
        //      so it's all char fields, has field-separators and <CR><LF> at the end.
        // We want a BINARY node which the rest of the program can utilize.
        // Also, once the WHOLE PROJECT (beyond just this A3) is completed, the
        // CountryCodeIndex WILL be a binary file, not just a text file (used for A3
        // testing).

        public void MakeBinNode(string aLine)
        {
            string[] field = new string[Globals.nOfFields];

            field = aLine.Split(' ');

            leafOrNonLeaf = Convert.ToChar(field[0]);

            int whichField = 1;
            for (int whichPair = 0; whichPair < Globals.m; whichPair++)
            {
                countryCode[whichPair] = field[whichField];
                drpOrTp [whichPair]= Convert.ToInt32(field[whichField + 1]);
                whichField += 2;
            }

            nextLeaf = Convert.ToInt32(field[whichField]);
        }
        //-------------------------------------------------------------------------
        public void ShowBinNode()
        {
            Console.WriteLine("\nLeafOrNonLeaf: {0}", leafOrNonLeaf);
            for (int i = 0; i < Globals.m; i++)
                Console.WriteLine("    at [{0}] is CountryCode: {1},  {2}: {3}",
                    i, countryCode[i],
                    leafOrNonLeaf == 'L'? "DRP" : "TP",
                drpOrTp[i]);
            Console.WriteLine("NextLeaf: {0}", nextLeaf);
            if (leafOrNonLeaf == 'N')
                Console.WriteLine("    since this is a NONleaf, " +
                    "the nextLeaf field is not relevant");
        }
    }
}
