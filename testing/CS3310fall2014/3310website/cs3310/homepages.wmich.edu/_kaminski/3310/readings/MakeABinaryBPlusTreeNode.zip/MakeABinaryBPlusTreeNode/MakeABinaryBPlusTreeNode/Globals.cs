﻿using System;

namespace MakeABinaryBPlusTreeNode
{
    public class Globals
    {
                        // HeaderRec data needed repeatedly throughout the program
        public static int m;
        public static int rootPtr;
        public static int firstLeaf;
                
                        // These are "constants" calculated ONCE AND FOR ALL in a
                        // SINGLE PLACE IN THE PROGRAM.

                        // The number of fields in a normal (non-Header) node.
        public static int nOfFields;
                        // These are used to calculate offset for random access.
                        // (These would be changed later when using a BINARY file
                        //      rather than A3's ASCII TEXT file).
        public static int sizeOfHeaderRec;          // NOT ACTUALLY USED IN THIS EXAMPLE
        public static int sizeOfTextFileNode;       // NOT ACTUALLY USED IN THIS EXAMPLE

        //***************************************************************************          
        public static void SetUpGlobalVariables(string headerRec)
        {
            string[] field = headerRec.Split(' ');

                         // The 5 fields are:
                         // m, rootPtr, nextEmpty, firstLeaf, nKV

            m =         Convert.ToInt32(field[0]);
            rootPtr =   Convert.ToInt32(field[1]);
            firstLeaf = Convert.ToInt32(field[3]);

                        // (We don't care about nextEmpty and nKV.
                        //      They'd be used if we were doing Insert & Delete).

            nOfFields = 1 + (2 * m) + 1;

                        // m, rootPtr, nextEmpty, firstLeaf, nKV
                        //      with spaces between fields & <CR><LF> at the end
            sizeOfHeaderRec = (5 * 3) + (4 * 1) + 2;
                        // leafOrNonLeaf, space,
                        // m pairs of:  countryCode, space, drpOrTp, space
                        // nextLeaf, <CR><LF>
            sizeOfTextFileNode = (1 + 1) + (m * (3 + 1 + 3 + 1)) + 3 + 2;
        }
    }
}
