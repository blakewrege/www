﻿// PROGRAM:  MakeABinaryBPlusTreeNode
// AUTHOR:  D.Kaminski
// DESCRIPTION:  This demonstrates 3 concepts:
//      1) A file contains a HeaderRec with data which needs to be repeatedly used
//          in the program.  So read it in ONCE AND FOR ALL AT THE START, and make
//          its data readily accessible to other parts of the program.
//      2) The program repeatedly needs to calculate certain "constants".  Rather
//          than repeatedly doing it in different parts of the program (so any change
//          in the future mean that all instances of the calculation have to be fixed),
//          instead do the calculations once and for all at the start.
//          (And do them as clear, step-by-step arithmetic expressions so it's obvious
//          exactly how it was done, rather than the programmer hand-calculating the
//          "final answer" and hardcoding the constant in the program).
//      3) The data file is an ASCII TEXT file.  But the program would like to handle
//          the data as if it was BINARY.  (And later, the file itself will actually
//          be a BINARY file (when the project is completed).
//          So this program converts an ASCII textFileNode into a binNode object.
//*************************************************************************************

using System;

namespace MakeABinaryBPlusTreeNode
{
    class Program
    {
        static void Main()
        {
            // This part is done in the Main program, once & for all:
            //      open the file and read in the HeaderRec which gets:
            //      m, rootPtr, nextEmpty, firstLeaf, nKV
            // (I'll just hardcode that here, for now).

            string headerRec = "007 056 058 011 239";

            // These 5 fields can either be stored as variables here, and then passed
            // individually to methods as parameter values, as needed.  OR, they can
            // be stored as globally available variables, accessible from anywhere in
            // the program.
            // (I'll use the global approach here). 

            Globals.SetUpGlobalVariables(headerRec);

            // I'm setting up a single object for a node, even though there are going
            // to be LOTS of nodes read in to just re-use the same storage space and
            // save time setting up a new object each time.
            //      [How many nodes will be read in altogether?
            //          Every QC transaction does a root-to-leaf search, so each
            //          transaction accesses height-of-the-tree number of nodes.
            //          Times however many transactions there are].
            //      [Pure OOP would probably suggest we set up a new node object each
            //          time].

            BPlusTreeNode binNode = new BPlusTreeNode();
            
            // With this approach, rather than putting the "setup" code in the 
            // constructor, each time we ReadANode we'll call the method to do the
            // "setup".  That is, call MakeABinNode, as shown below.
                       
            //************************************************************************
            // The following code is not in Main.  It's something done in the QC or PC
            // transaction handler module.            
            
            // At some point you'll read in some node.
            // For example, suppose I just read in the rootNode at RRN 056.
            // (I'll just hardcode that here, for now).

            string textFileNode =
                "N IDN 023 ZWE 007 ^^^ 000 ^^^ 000 ^^^ 000 ^^^ 000 ^^^ 000 000";

            binNode.MakeBinNode(textFileNode);

            binNode.ShowBinNode();              // just for developer to test it

            // At some point later you'll read in some other node.
            // For example, suppose I just read in a LEAF node RRN 028
            //      (however I happened to get to wanting that node).
            // (I'll just hardcode that here, for now).

            textFileNode =
                "L NOR 047 NPL 015 NRU 136 NZL 049 OMN 084 PAK 077 PAN 046 042";

            binNode.MakeBinNode(textFileNode);

            binNode.ShowBinNode();              // just for developer to test it

            //*************************************** PAUSE
            Console.WriteLine("\nHit ENTER to quit");
            Console.ReadLine();
        }
    }
}
