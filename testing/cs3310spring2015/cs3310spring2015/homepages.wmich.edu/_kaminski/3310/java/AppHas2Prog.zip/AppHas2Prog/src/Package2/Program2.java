// PROJECT:  AppHas2Prog
// AUTHOR:  D. Kaminski
// DESCRIPTION:  See comments at the top of Program1.
// **************************************************************************************

package Package2;

public class Program2 
{
    public static void main(String[] args) 
    {
        System.out.println("Hello from Program 2!");
    }
}
