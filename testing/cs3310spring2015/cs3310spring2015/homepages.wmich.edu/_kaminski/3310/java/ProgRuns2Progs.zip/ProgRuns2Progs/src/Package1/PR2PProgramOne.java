// PROGRAM:  Program1 in NEW APPLICATION:  ProgRuns2Prog
//      - see top comment in DriverProgram.
// AUTHOR:  D. Kaminski
// NO CHANGES were made to this code from the earlier app.
// **************************************************************************************

package Package1;

import Package2.PR2PMessageClass;

public class PR2PProgramOne
{
    public static void main(String[] args) 
    {
        PR2PMessageClass.DisplayMessage("Program One");
    }
}