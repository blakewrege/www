// PROGRAM:  Program2 in NEW APPLICATION:  ProgRuns2Prog
//      - see top comment in DriverProgram.
// AUTHOR:  D. Kaminski
// NO CHANGES were made to this code from the earlier app.
// **************************************************************************************

package Package2;

public class PR2PProgramTwo
{
    public static void main(String[] args) 
    {
        PR2PMessageClass.DisplayMessage("Program Two");        
    }
}
