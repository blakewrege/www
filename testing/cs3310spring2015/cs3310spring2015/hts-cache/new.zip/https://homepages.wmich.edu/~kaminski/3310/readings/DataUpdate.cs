<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<HTML><HEAD>
<TITLE>403 Forbidden</TITLE>
</HEAD><BODY>
<H1>Forbidden</H1>
You don't have permission to access /~kaminski/3310/readings/DataUpdate.cs
on this server.<P>
<HR>
<ADDRESS>Apache/1.3.29 Server at homepages.wmich.edu Port 443</ADDRESS>
</BODY></HTML>
